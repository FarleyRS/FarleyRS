package com.example.projeto.recycler_view;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Grupos {

    public int id;
    public String nome;
    public String tema;
    public Date data_de_entrega;


    public Grupos(String nome){
        this.nome = nome;
    }
    public Grupos(String nome,String tema){
        this.nome = nome;
        this.tema = tema;
    }
    public Grupos(String nome,String tema, Date data_de_entrega){
        this.nome = nome;
        this.tema = tema;
        this.data_de_entrega = data_de_entrega;
    }

    public void setGrupo(){

    }
    public static List<Grupos> getGrupos(){
        List<Grupos> gruposList = new ArrayList<>();
        gruposList.add(new Grupos("Desenvolvimento WEB"));
        gruposList.add(new Grupos("Desenvolvimento Android"));
        gruposList.add(new Grupos("Topicos Especiais"));
        return gruposList;
    }
}
