package com.example.projeto;

public class Usuarios {
    String nome;
    String email;
    int id_grup;
    Usuarios[] contatos;


}
