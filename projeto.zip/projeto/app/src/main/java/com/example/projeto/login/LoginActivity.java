package com.example.projeto.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.projeto.MainActivity;
import com.example.projeto.R;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
    public void onClickRegistre(View v){
        startActivity(new Intent(this, RegistreActivity.class));
    }
    public void onClickLogin(View v){
        startActivity(new Intent(this, MainActivity.class));
    }
}